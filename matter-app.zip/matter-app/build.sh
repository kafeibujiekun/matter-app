#!/bin/bash

CHIP_DIR="/opt/connectedhomeip"

mkdir -p zapgen/zap-generated

python ${CHIP_DIR}/scripts/tools/zap/generate.py \
    --prettify-output \
    -t ${CHIP_DIR}/src/app/zap-templates/app-templates.json \
    -z ${CHIP_DIR}/src/app/zap-templates/zcl/zcl.json \
    -o $PWD/zapgen/zap-generated \
    $PWD/lighting-app.zap

python ${CHIP_DIR}/scripts/tools/zap/generate.py \
    -z ${CHIP_DIR}/src/app/zap-templates/zcl/zcl.json \
    -o $PWD \
    $PWD/lighting-app.zap

python ${CHIP_DIR}/scripts/codegen.py \
    --generator cpp-app \
    --output-dir $PWD/zapgen/zap-generated/ \
    $PWD/lighting-app.matter

gn gen out && ninja -C out
